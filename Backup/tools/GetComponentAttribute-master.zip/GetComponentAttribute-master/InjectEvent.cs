﻿public delegate void InjectEvent<in T, in J, in K>(T t, J j, K k);
