﻿public enum GetComponentFrom
{
    Self,
    SceneObject,
    TargetGameObject
}