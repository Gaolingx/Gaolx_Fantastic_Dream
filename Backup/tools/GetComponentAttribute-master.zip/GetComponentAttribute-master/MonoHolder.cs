﻿public class MonoHolder<T, J>
{
    public T t;
    public J j;

    public MonoHolder(T t, J j)
    {
        this.t = t;
        this.j = j;
    }
}